<!DOCTYPE html>
<html lang = "pl-PL">
<head>
	<meta charset = "UTF-8"/>
	<title>Obuwie</title>
	<link rel = "stylesheet" href = "style.css"/>
</head>
<body>
<?php
	$pol = mysqli_connect("localhost","root","","obuwie");
?>
<header>
	<h1>Obuwie męskie</h1>
</header>

<main>
<form action = "zamow.php" method = "POST">
<label for = "modl">Model: </label>
<select id = "modl" name = "modl" class = "kontrolki">
<?php
	$li_que = mysqli_query($pol, "SELECT model FROM produkt;");
	while ($list = mysqli_fetch_assoc($li_que))
	{
		echo "<option>".$list['model']."</option>";
	}
?>
</select>

<label for = "rozm">Rozmiar: </label>
<select id = "rozm" name = "rozm" class = "kontrolki">
	<option>40</option>
	<option>41</option>
	<option>42</option>
	<option>43</option>
</select>

<label for = "liczpar">Liczba par: </label>
<input type = "number" id = "liczpar" name = "liczpar" class = "kontrolki"/>

<button type = "submit" class = "kontrolki">Zamów</button>
</form>
<?php
	$blk_que = mysqli_query($pol, "SELECT b.model, nazwa, cena, nazwa_pliku FROM buty b JOIN produkt p ON b.model = p.model;");
	while ($blk = mysqli_fetch_assoc($blk_que))
	{
		echo "<div class = 'buty'>
		<img src ='".$blk['nazwa_pliku']."' alt = 'but męski'/>
		<h2>".$blk['nazwa']."</h2>
		<h5>Model: ".$blk['model']."</h5>
		<h4>Cena: ".$blk['cena']."</h4>
		</div>";
	}
	mysqli_close($pol);
?>
</main>

<footer>
	<p>Autor strony: 297497299</p>
</footer>
</body>
</html>