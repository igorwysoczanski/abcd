<!DOCTYPE html>
<html lang = "pl-PL">
<head>
	<meta charset = "UTF-8"/>
	<title>Obuwie</title>
	<link rel = "stylesheet" href = "style.css"/>
</head>
<body>
<header>
	<h1>Obuwie męskie</h1>
</header>

<main>
<h2>Zamówienie</h2>
<?php
	$pol = mysqli_connect("localhost","root","","obuwie");
	error_reporting(0);
	$model = $_POST["modl"];
	$rozmiar = $_POST["rozm"];
	$licz_par = $_POST["liczpar"];
	$srch_que = mysqli_query($pol, "SELECT nazwa, cena, kolor, kod_produktu, material, nazwa_pliku FROM buty b JOIN produkt p ON b.model = p.model WHERE b.model = '".$model."';");
	$wynik = mysqli_fetch_assoc($srch_que);
	$warcal = $wynik['cena']*$licz_par;
	if ($model != "")
	{
		echo "<img src = '".$wynik['nazwa_pliku']."' alt = 'but męski'/>
		<h2>".$wynik['nazwa']."</h2>
		<p>cena za ".$licz_par." par: ".$warcal."zł</p>
		<p>Szczegóły produktu: ".$wynik['kolor'].", ".$wynik['material']."</p>
		<p>Rozmiar: ".$rozmiar."</p>";
	}
	mysqli_close($pol);
?>
<a href = "index.php">Strona główna</a>
</main>

<footer>
	<p>Autor strony: 297497299</p>
</footer>
</body>
</html>