<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Hurtownia szkolna</title>
    <link rel="stylesheet" type="text/css" href="style1.css">
</head>
<body>
    <header>
        <h1>Hurtownia z najlepszymi cenami</h1>
    </header>

    <aside id="lewy">
    <h2>Nasze ceny</h2>
    <table>
       <tr><th>Produket</th><th>Cena</th>
        <?php
            $pol=mysqli_connect("localhost", "root","", "sklep");
            $zap1=mysqli_query($pol,"SELECT `nazwa`,`cena` FROM `towary` LIMIT 4;");
            while($linijka = mysqli_fetch_assoc($zap1)){
            echo"<tr>";
            echo"<td>".$linijka['nazwa'].".</td>";
            echo"<td>".$linijka['cena']."</td>";
            echo"</tr>";
            }
        ?>
    </table>
   
    </aside>

        <main id="srodek">
            <h2>Koszt zakupów</h2>
            <form action="egzamin.html" method="post" >
                Wybierz artykuł
                <select name="Produkt">
                    <option value="Zeszyt60">Zeszyt 60 kartek</option>
                    <option value="Zeszyt32">Zeszyt 32 karki</option>
                    <option value="Cyrkiel">Cyrkiel</option>
                    <option value="Linijka">Linijka 30cm</option>
                </select>
            </form>
            <br>
            Liczba sztuk:
            <input type="number" name="liczba">
            <br>
            <button>Oblicz</button>
        </main>
   

    <aside id="prawy">
        <h2>Kontakt</h2>
        <img src="zakupy.png">
        <p><a href="hurt@pocztao2.pl">e-mail:hurt@poczta2.pl</a></p>
    </aside>

    <footer>
        <h4>Witrynę wykonał:00000000000</h4>
    </footer>

</body>
</html>