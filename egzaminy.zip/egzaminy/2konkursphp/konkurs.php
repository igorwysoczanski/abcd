<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>WOLONTARIAT SZKOLNY</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <header>
        <h1>KONKURS - WOLONTARIAT SZKOLNY</h1>
    <header>
    
        <main id="lewy">
            <h3>Konkursowe nagrody</h3>
            
            <form action="konkurs.php" method="POST">
                <input type="submit" value="Losuj nowe nagrody">
            </form>

            <table>
                <tr>
                    <th>Nr</th>
                    <th>Nazwa</th>
                    <th>Opis</th>
                    <th>Wartość</th>
                </tr>
                <?php 
                    $pol=mysqli_connect("localhost","root","","konkurs");
					$zap1=mysqli_query($pol, "SELECT `nazwa`,`opis`,`cena` FROM `nagrody` ORDER BY RAND() LIMIT 5;");
                    $numer = 1;
					while($linijka=mysqli_fetch_assoc($zap1)){
                        echo "<tr>";
                        echo "<td>".$numer."</td>";
                        echo "<td>".$linijka["nazwa"]."</td>";
                        echo "<td>".$linijka["opis"]."</td>";
                        echo "<td>".$linijka["cena"]."</td>";
                        echo "</tr>";
                    }
                ?>
            </table>
        </main>
        
        <aside id="prawy">
            <img src="puchar.png" alt="Puchar dla wolontariusza">
            <h4>Polecane linki</h4>

            <ul>
                <li><a href="kw1.png">Kwerenda 1</a></li>
                <li><a href="kw2.png">Kwerenda 2</a></li>
                <li><a href="kw3.png">Kwerenda 3</a></li>
                <li><a href="kw4.png">Kwerenda 4</a></li>
            </ul>
        </aside>

    <footer>
        <p>Numer zdającego: 000000000</p>
    </footer>
</body>
</html>