idZamowienia = 0;
const ilosc1 = document.getElementById("i1");
const ilosc2 = document.getElementById("i2");
const ilosc3 = document.getElementById("i3");
const ilosc4 = document.getElementById("i4");


const iloscProduktow = [ilosc1,ilosc2,ilosc3,ilosc4]
function sprawdz(){
    for (let i = 0; i< iloscProduktow.length; i++) {
        if(iloscProduktow[i].innerText==0){
            iloscProduktow[i].style.backgroundColor = "red";
        }else if(iloscProduktow[i].innerText > 0 && iloscProduktow[i].innerText <= 5){
            iloscProduktow[i].style.backgroundColor = "yellow";
        }else{
        iloscProduktow[i].style.backgroundColor = "honeydew";
        }
    }
}

function aktualizuj(id){
    let nowaIlosc = prompt("podaj nową ilość:");
    document.getElementById(id).innerText = nowaIlosc;
    sprawdz();

}

function zamow(id){
    idZamowienia++;
    const produkt=document.getElementById(id).innerText
    alert(`Zamówienie nr: ${idZamowienia} Produkt: ${produkt}`);
}

sprawdz();