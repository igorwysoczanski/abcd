<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>KOŁO SZACHOWE</title>
    <link rel="stylesheet" type="text/css" href="styleszachy.css">

</head>
<body>
    <header>
        <h1><em>Koło szachowe gambit piona</em></h1>
    </header>
    <main>
        <h3>Najlepsi gracze naszego koła</h3>
        <table>
            <tr>
            <th>Pozycja</th><th>Pseudonim</th><th>Tytuł</th><th>Ranking</th><th>Klasa</th>
            </tr>
             <?php 
            error_reporting(0);
             $pol1 =mysqli_connect("localhost", "root", "","szachy");
             $zap1 = mysqli_query($pol1, "SELECT `pseudonim`,`tytul`,`ranking`,`klasa` FROM `zawodnicy` WHERE `ranking` > 2787 ORDER BY ranking DESC;");
             $numer = 1;
             while ($wiersz1 = mysqli_fetch_assoc  ($zap1))
             {
                
                
                 echo "<tr>";
                 echo "<td>".$numer."</td>";
                 echo "<td>".$wiersz1['pseudonim']."</td>";
                 echo "<td>".$wiersz1['tytul']."</td>";
                 echo "<td>".$wiersz1['ranking']."</td>";
                 echo "<td>".$wiersz1['klasa']."</td>";
                 echo "</tr>";
                 $number++;
             }
             mysqli_close($pol1);
            
            
            ?>
            
        </table>
        <form action="szachy.php" method="post">
            <input type="submit" value="Losuj nową parę graczy">
            <?php 
            $pol2 =mysqli_connect("localhost", "root", "","szachy");
            $zap2=mysqli_query($pol2 , "SELECT `pseudonim` , `klasa`FROM `zawodnicy`  ORDER BY RAND() LIMIT 2");
            while ($wiersz2 = mysqli_fetch_assoc  ($zap2))
            {
                echo"<h4>";
                echo "<tr>";
                echo "<td>".$wiersz2['pseudonim']."</td>";
                echo "<td>".$wiersz2['tytul']."</td>";
                echo "<td>".$wiersz2['ranking']."</td>";
                echo "<td>".$wiersz2['klasa']."</td>";
                echo "</tr>";
                echo"</h4>";
            }
            mysqli_close($pol2);
            
            
            
            ?>
        </form>
        <p>Legenda: AM - Absolutny Mistrz, SM - Szkolny Mistrz, PM - Mistrz Poziomu, KM - Mistrz Klasowy</p>
    </main>
    <aside>
    <ul>
        <li><a href="kw1.png">Kwerenda 1</a></li>
        <li><a href="kw2.png">Kwerenda 2</a></li>
        <li><a href="kw3.png">Kwerenda 3</a></li>
        <li><a href="kw4.png">Kwerenda 4</a></li>
    </ul>
    <img src="logo.png" alt="Logo koła">
    </aside>
<footer>
    <p>Numer zdającego: 000000000</p>
</footer>

</body>


</html>
