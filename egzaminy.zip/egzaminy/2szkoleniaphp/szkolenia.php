<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Firma szkoleniowa</title>
    <link rel="Stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="container">
    <header>
        <img src="baner.jpg" alt="Szkolenia">
    </header>
    
    
    <aside>

        <ul>
            <li><a href="index.html">Strona główna</a></li>
            <li><a href="szkolenia.php">Szkolenia</a></li>
        </ul>
    </aside>

    <main>
        <?php
    $pol=mysqli_connect("localhost", "root", "","firma");
    $query = "SELECT `Data`,`Temat` FROM `szkolenia` order BY `Data` ASC;";
    $result = mysqli_query($pol,$query);
    $plik = fopen("harmonogram.txt", "w");
    
    while ($row = mysqli_fetch_array($result)) {
    $wiersz = $row['Data'] . " " . $row['Temat'];
    echo "<p>$wiersz</p>";
    fwrite($plik, $wiersz . "\n");
    }
    fclose($plik);
    mysqli_close($pol)

?>
    </main>

    <footer>
        <h2>Firma szkoleniowa, ul. Główna1, 23-456 Warszawa</h2>
        <p>Autor:Igor Wysoczański</p>
    </footer>

    </div>

    
</body>
</html>