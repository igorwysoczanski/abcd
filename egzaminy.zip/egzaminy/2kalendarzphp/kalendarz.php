﻿<!DOCTYPE html>
<html lang="pl">
<head>
<title>kalendarz</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="styl.css">

 
</head>
<body>
	<header>
		<h1>Dni, miesiące, lata...</h1>
	</header>
	<section id="napis">
	<p>
		<?php
		error_reporting(0);
		$pol=mysqli_connect("localhost","root","","kalendarz");
		$data=date("m-d");
		$dnitygodnia=date("l");
		$dnitygodniapolskie=["Monday"=>"Poniedziałek", "Tuesday"=>"wtorek", "Wednesday"=>"środa","Thursday"=>"czwartek","Friday"=>"piątek","Saturday"=>"sobota","Sunday"=>"niedziela"];
		$tygodniepopolsku=$dnitygodniapolskie[$dnitygodnia];
		$zap2=mysqli_query($pol,"SELECT `imiona` FROM `imieniny` WHERE `data`='$data'; ");
		while($wiersz=mysqli_fetch_row($zap2))
		{
			$imieniny=$wiersz[0];
		}
		echo "Dzisiaj jest $tygodniepopolsku  $data imieniny: $imieniny";
		?>
	</p>
	</section>
	<aside id="lewy">
		<table>
		<tr><th>liczba dni</th><th>miesiąc</th></tr>
		<tr><td rowspan="6">31</td><td>styczeń</td></tr>
		<tr><td>marzec</td></tr>
		<tr><td>maj</td></tr>
		<tr><td>lipiec</td></tr>
		<tr><td>sierpień</td></tr>
		<tr><td>październik</td></tr>
		<tr><td rowspan='4'>30</td><td>kwiecień</td></tr>
		<tr><td>czerwiec</td></tr>
		<tr><td>wrzesień</td></tr>
		<tr><td>listopad</td></tr>
		<tr><td>28 lub 29</td><td>luty</td></tr>
		</table>
	</aside>
	<main>
		<h2>Sprawdź kto ma urodziny</h2>
		<form action="kalendarz.php" method="POST">
		<input type="date" name="data" min="2024-01-01" max="2024-12-31"required>
		<input type="submit" value="Wyślij">
		</form>
		<?php
		$dat=$_POST["data"];
		$przekształcenie=date("m-d",strtotime($dat));
		$zap2=mysqli_query($pol,"SELECT `imiona` FROM `imieniny` WHERE `data`='$przekształcenie'; ");
		while($wiersz=mysqli_fetch_row($zap2))
		{
			$imiona=$wiersz[0];
		}
		echo "Dnia $dat są imieniny: $imiona";
		mysqli_close($pol);
		?>
	</main>
	<aside id="prawy">
		<a href="https://pl.wikipedia.org/wiki/Kalendarz_Majów" target="_blank">
		<img src="kalendarz.gif" alt="Kalendarz Majów">
		</a>
		<h2>Rodzaje kalendarzy</h2>
		<ol>
			<li>Słoneczny
			<ul>
				<li>kalendarz Majów</li>
				<li>juliański</li>
				<li>gregoriański</li>
			</ul>
			</li>
			<li> Księżycowy
			<ul>
				<li>starogrecki</li>
				<li>babiloński</li>
			</ul>
			</li>
		</ol>
	</aside>
	<footer>
	<p>Stronę opracowała:Monika Kuś</p>
	</footer>
	
</html>